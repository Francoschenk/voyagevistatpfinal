import './Nadvar.css';

function Nadvar(){
    return(
        <div className="nadvar" >
        <Nadvar>
            <h3 className='leon'>leon</h3>
            <h3 className='Tigre'>Tigre</h3>
            <h3 className='Mono'>Mono</h3>
        </Nadvar>
        </div>
    )
}

export default Nadvar