
import React from "react";
import Bnadvar from "../Bnadvar/Bnadvar";
import './Header.css';
// import Bnadvar from './components/Bnadvar/Bnadvar';

function Header(){
    return(
        <header className="Header">
            {/* <Bnadvar></Bnadvar> */}
            <Bnadvar />
            <p>jcjcccc</p>
        </header>
    )
}

export default Header;
