
function ListaCasas(){
    return(
        <div className="listaCasas" >
            <ul>
                <li>Elemento 1</li>
                <li>Elemento 2</li>
                <li>Elemento 3</li>
                <li>Elemento 4</li>
            </ul>
        </div>
    )
}

export default ListaCasas