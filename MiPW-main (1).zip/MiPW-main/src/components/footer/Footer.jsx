import './footer.css';

function Footer(){
    return(
        <footer className="footer">
        <h1 >mi proyecto react derechos resevados@2024</h1>
        <h2> haber dddddd</h2>
        </footer>
    )
}

export default Footer