import App from "../../App";
import Header from "../Header/Header";
import FormularioI from "../formularioI/formularioI";

function Home(){
    <>
    <Header />
    <FormularioI />
    </>

}

export default Home;