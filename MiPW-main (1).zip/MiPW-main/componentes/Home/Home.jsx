import Header from "../Header/Header";
import FormularioI from "../formulariol/formularioI";

function Home(){
    <>
    <Header />
    <FormularioI />
    </>

}

export default Home;